<?php
/*
Plugin Name: Maestro CRM
Description: CRM-система для автосервиса (клиенты, автомобили, заказы, склад, отчёты).
Version: 1.0.0
Author: vipersone
Author URI: https://github.com/vipersone-prince
*/
